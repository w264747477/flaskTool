from app import db, loginmanager
from flask_login import UserMixin
from datetime import datetime

class User(db.Model, UserMixin):
    __tablename__ = 'syuser'
    ID = db.Column(db.String(36), primary_key=True)
    CREATEDATETIME = db.Column(db.DateTime, index=True, default=datetime.now)
    UPDATEDATETIME = db.Column(db.DateTime, index=True, default=datetime.now)
    LOGINNAME = db.Column(db.String(100), unique=True, index=True)
    # PWD = db.Column(db.String(100))
    NAME = db.Column(db.String(100))
    SEX = db.Column(db.String(1))
    AGE = db.Column(db.Integer)
    PHOTO = db.Column(db.String(200))
    EMPLOYDATE = db.Column(db.DATETIME, default=datetime.now)

    def get_id(self):
        return str(self.ID)

    def have_permission(self, url):
        permissions = []
        for role in self.roles:
            permissions.extend([resource for resource in role.resources])

        if filter(lambda x: x.URL == url, permissions):
            return True

        permissions = []
        for organization in self.organizations:
            permissions.extend([resource for resource in organization.resources])

        return filter(lambda x: x.NAME == url, permissions)
        
    def __repr__(self):
        return '<User %r>\n' %(self.NAME)

    def to_json(self):
        return {
            'id': self.ID,
            'createdatetime': self.CREATEDATETIME.strftime('%Y-%m-%d %H:%M:%S'),
            'updatedatetime': self.UPDATEDATETIME.strftime('%Y-%m-%d %H:%M:%S'),
            'loginname': self.LOGINNAME,
            'name': self.NAME,
            'sex': self.SEX,
            'age': self.AGE,
            'photo': self.PHOTO,
            #'employdate': self.EMPLOYDATE.strftime('%Y-%m-%d %H:%M:%S'),
        }        