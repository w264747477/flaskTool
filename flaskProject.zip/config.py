import os

import redis
class Config(object):
    SECRET_KEY='vjjkkakaa1222'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DEV_DATABASE_URI') or \
                              'mysql+pymysql://root:wang7777qq@43.142.9.84/authbase?charset=utf8'
    # redis
    # REDIS_HOST='127.0.0.1'
    # REDIS_POST=6379
    # flask-session配置
    # SESSION_TYPE='redis'
    # SESSION_REDIS=redis.StrictRedis(host=REDIS_HOST,port=REDIS_POST)
    SESSION_USE_SIGNER=True
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    PERMANENT_SESSION_LIFETIME=86400   #session数据有效时间
class DevelopmentConfig(Config):
    # 开发模式配置信息
    DEBUG = True
    # 数据库
    # SQLALXHEMY_DATABASE_URI="mysql://root:mysql@localhost:3306/pytest"
    # SQLALCHEMY_DATABASE_URI = os.environ.get('DEV_DATABASE_URI') or \
    #                           'mysql+pymysql://root:123456@127.0.0.1/authbase?charset=utf8'
    SQLQLCHEMY_TRACK_MODIFICATIONS = True
    pass
class ProductConfig(Config):
    # 生产环境
    # 数据库
    # SQLALXHEMY_DATABASE_URI="mysql://root:mysql@localhost:3306/pytest"
    # SQLALCHEMY_DATABASE_URI = os.environ.get('DEV_DATABASE_URI') or \
    #                           'mysql+pymysql://root:123456@43.142.9.84/authbase?charset=utf8'
    SQLQLCHEMY_TRACK_MODIFICATIONS = True
    pass
config_map={
    "develop":DevelopmentConfig,
    "product":ProductConfig
}