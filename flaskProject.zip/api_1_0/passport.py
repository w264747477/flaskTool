# coding:utf-8
from . import api
from flask import  request,jsonify
@api.route("/users",methods=["POST"])
def register():

    pass