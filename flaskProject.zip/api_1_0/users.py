from api_1_0 import api
from tools._init_ import db
from flask import jsonify
from models import User
@api.route('/index')
def index():
   user = User.query.all()
   print(user)
   # current_app.error("fkkbl")
   # current_app.warn('fbbb')
   # current_app.info("vvv")
   # current_app.debug('vvzz')
   # logging.error("fkkbl")
   # logging.warn('fbbb')
   # logging.info("vvv")
   # logging.debug('vvzz')
   # user = User()
   # user.ID = '1'
   # user.NAME ='超级管理员'
   # user.SEX ='女'
   # user.LOGINNAME='fuu'
   # # add current use to new user
   # # current_user.roles.append(user)
   # db.session.add(user)
   # db.session.commit()

   return jsonify({'success': True, 'msg': '新建用户成功！默认密码：123456'})